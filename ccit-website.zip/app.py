from flask import Flask, render_template, request
import os

app = Flask(__name__)

# SEO and meta data
def get_meta_data(page_title, description=""):
    return {
        'title': f"{page_title} - CCIT | College of Communication and Information Technology",
        'description': description or "College of Communication and Information Technology - Leading education in Computer Science and Information Technology",
        'keywords': "CCIT, Computer Science, Information Technology, College, University, Education, Technology"
    }

@app.route('/')
def home():
    meta = get_meta_data("Home", "Welcome to the College of Communication and Information Technology - Shaping the future of technology education")
    return render_template('home.html', meta=meta)

@app.route('/about')
def about():
    meta = get_meta_data("About Us", "Learn about our vision, mission, goals and quality policy at CCIT")
    return render_template('about.html', meta=meta)

@app.route('/faculty')
def faculty():
    meta = get_meta_data("Faculty", "Meet our distinguished faculty members from Computer Science and Information Technology departments")
    
    # Faculty data structure
    faculty_data = {
        'dean': {
            'name': 'Dr. Maria Santos',
            'position': 'Dean of CCIT',
            'image': '/static/images/faculty/dean.jpg',
            'department': 'Administration'
        },
        'cs_chair': {
            'name': 'Dr. John Anderson',
            'position': 'Computer Science Program Chair',
            'image': '/static/images/faculty/cs_chair.jpg',
            'department': 'Computer Science'
        },
        'it_chair': {
            'name': 'Dr. Sarah Johnson',
            'position': 'Information Technology Program Chair', 
            'image': '/static/images/faculty/it_chair.jpg',
            'department': 'Information Technology'
        },
        'cs_faculty': [
            {'name': 'Prof. Michael Chen', 'image': '/static/images/faculty/cs1.jpg'},
            {'name': 'Dr. Lisa Rodriguez', 'image': '/static/images/faculty/cs2.jpg'},
            {'name': 'Prof. David Kim', 'image': '/static/images/faculty/cs3.jpg'},
            {'name': 'Dr. Emily Watson', 'image': '/static/images/faculty/cs4.jpg'}
        ],
        'it_faculty': [
            {'name': 'Prof. Robert Taylor', 'image': '/static/images/faculty/it1.jpg'},
            {'name': 'Dr. Jennifer Lee', 'image': '/static/images/faculty/it2.jpg'},
            {'name': 'Prof. Mark Wilson', 'image': '/static/images/faculty/it3.jpg'},
            {'name': 'Dr. Amanda Brown', 'image': '/static/images/faculty/it4.jpg'}
        ]
    }
    
    return render_template('faculty.html', meta=meta, faculty=faculty_data)

@app.route('/organizations')
def organizations():
    meta = get_meta_data("Student Organizations", "Discover student organizations and their leadership in CCIT")
    
    organizations = [
        {
            'name': 'Computer Science Society',
            'description': 'Advancing computer science education and innovation',
            'officers': [
                {'name': 'Alex Thompson', 'position': 'President'},
                {'name': 'Jessica Martinez', 'position': 'Vice President'},
                {'name': 'Ryan Park', 'position': 'Secretary'},
                {'name': 'Sophie Davis', 'position': 'Treasurer'}
            ],
            'platform': 'Promoting coding competitions, hackathons, and tech workshops'
        },
        {
            'name': 'IT Student Association',
            'description': 'Connecting IT students with industry professionals',
            'officers': [
                {'name': 'Daniel Garcia', 'position': 'President'},
                {'name': 'Maya Patel', 'position': 'Vice President'},
                {'name': 'Chris Wong', 'position': 'Secretary'},
                {'name': 'Olivia Smith', 'position': 'Treasurer'}
            ],
            'platform': 'Industry networking, certification programs, and career development'
        },
        {
            'name': 'Tech Innovation Club',
            'description': 'Fostering innovation and entrepreneurship in technology',
            'officers': [
                {'name': 'Jordan Miller', 'position': 'President'},
                {'name': 'Zoe Chen', 'position': 'Vice President'},
                {'name': 'Ethan Johnson', 'position': 'Secretary'},
                {'name': 'Isabella Rodriguez', 'position': 'Treasurer'}
            ],
            'platform': 'Startup incubation, innovation challenges, and tech entrepreneurship'
        }
    ]
    
    return render_template('organizations.html', meta=meta, organizations=organizations)

@app.route('/news')
def news():
    meta = get_meta_data("College News", "Stay updated with the latest news and events from CCIT")
    
    news_items = [
        {
            'title': 'CCIT Students Win National Programming Competition',
            'date': '2024-03-15',
            'summary': 'Our Computer Science students secured first place in the national coding championship.',
            'image': '/static/images/news/news1.jpg'
        },
        {
            'title': 'New AI Research Lab Opens',
            'date': '2024-03-10',
            'summary': 'State-of-the-art artificial intelligence research facility now available for students and faculty.',
            'image': '/static/images/news/news2.jpg'
        },
        {
            'title': 'Industry Partnership with Tech Giants',
            'date': '2024-03-05',
            'summary': 'CCIT announces new partnerships with leading technology companies for internships and research.',
            'image': '/static/images/news/news3.jpg'
        }
    ]
    
    return render_template('news.html', meta=meta, news=news_items)

@app.route('/computer-science')
def computer_science():
    meta = get_meta_data("Computer Science Department", "Explore our comprehensive Computer Science programs and curriculum")
    return render_template('computer_science.html', meta=meta)

@app.route('/information-technology')
def information_technology():
    meta = get_meta_data("Information Technology Department", "Discover our innovative Information Technology programs and opportunities")
    return render_template('information_technology.html', meta=meta)

@app.route('/terms')
def terms():
    meta = get_meta_data("Terms of Service", "Terms and conditions for using the CCIT website")
    return render_template('terms.html', meta=meta)

@app.route('/privacy')
def privacy():
    meta = get_meta_data("Privacy Policy", "Privacy policy and data protection information for CCIT website users")
    return render_template('privacy.html', meta=meta)

@app.errorhandler(404)
def not_found(error):
    meta = get_meta_data("Page Not Found", "The requested page could not be found")
    return render_template('404.html', meta=meta), 404

if __name__ == '__main__':
    app.run(debug=True)
